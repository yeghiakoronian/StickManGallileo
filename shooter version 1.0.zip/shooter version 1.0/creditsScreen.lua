---------------------------------------------------------------------------------
--
-- creditsScreen.lua
--
---------------------------------------------------------------------------------

local storyboard = require( "storyboard" )
local scene = storyboard.newScene()

---------------------------------------------------------------------------------
-- BEGINNING OF YOUR IMPLEMENTATION
---------------------------------------------------------------------------------

local backgroundImage

-- Called when the scene's view does not exist:
function scene:createScene( event )
	local screenGroup = self.view
	
	-- completely remove options
	storyboard.removeScene( "options" )

	
	print( "\ncreditsScreen: createScene event" )
end


-- Called immediately after scene has moved onscreen:
function scene:enterScene( event )
	local screenGroup = self.view
	
	print( "creditsScreen: enterScene event" )
	
	backgroundImage = display.newImageRect( "creditsScreen.png", 480, 320 )
	backgroundImage.x = 240; backgroundImage.y = 160
	screenGroup:insert( backgroundImage )
	
	local changeToOptions = function( event )
		if event.phase == "began" then
			
			storyboard.gotoScene( "options", "crossFade", 500  )
			
		end
	end
	
	backgroundImage:addEventListener( "touch", changeToOptions)
	
end


-- Called when scene is about to move offscreen:
function scene:exitScene()
	
	print( "creditsScreen: exitScene event" )

end


-- Called prior to the removal of scene's "view" (display group)
function scene:destroyScene( event )
	
	print( "((destroying creditsScreen's view))" )
	
end

---------------------------------------------------------------------------------
-- END OF YOUR IMPLEMENTATION
---------------------------------------------------------------------------------

-- "createScene" event is dispatched if scene's view does not exist
scene:addEventListener( "createScene", scene )

-- "enterScene" event is dispatched whenever scene transition has finished
scene:addEventListener( "enterScene", scene )

-- "exitScene" event is dispatched before next scene's transition begins
scene:addEventListener( "exitScene", scene )

-- "destroyScene" event is dispatched before view is unloaded, which can be
scene:addEventListener( "destroyScene", scene )

---------------------------------------------------------------------------------

return scene