
--local gameGroup = display.newGroup()
system.activate( "multitouch" )
local storyboard = require( "storyboard" )
local scene = storyboard.newScene()
local facebook = require "facebook"
local sprite = require "sprite"
local physics = require "physics"
local Vector2D = require "Vector2D"
require "auxFunctions"
local dpadMgr = require "dpad"
local ui = require "ui"
local perspective=require("perspective")
local camera=perspective.createView()
local dpad = nil
local angleOld = 0
local angleBullet = 0

local charObject
local charObjectHand
local playerSheetData
local playerSheet
local playerSequenceData
--local enemy

local motionx = 0
local speed = 5
local charInAir = true
local leftarrow
local uparrow
local rightarrow
local background
local dpadScreen
local ground
local bullets = display.newGroup( )
local enemies= display.newGroup()
local powerUps = display.newGroup( )
local physicsData1 = (require "bullet1").physicsData(1.0)
local physicsData2 = (require "cratePhysics").physicsData(1.0)
_G.W = display.contentWidth
_G.H = display.contentHeight

local startEnemy
local startShoot
local gameScore = 0
local scoreText
local highScoreText
local highScoreame
local gameLives = 20
local deadenemy 
local gameIsActive = false
local livesText

local pauseBtn
local pauseMenuBtn
local pauseBG
local menuBtn
local fbBtn
local btnSound = audio.loadSound( "btnSound.wav" )
--local zombieMoan = audio.loadSound("zombieMoan.mp3")
local bloodSplat = audio.loadSound("bloodSplat.mp3" )
audio.setVolume( 1, { channel=1 } )
local shotsnd = audio.loadSound("shot.mp3")
audio.setVolume( 0.5, { channel=2 } )
local powerlife = audio.loadSound("powerup.mp3")
audio.setVolume( 1, { channel=3 } )



local saveValue = function( strFilename, strValue )
	-- will save specified value to specified file
	local theFile = strFilename
	local theValue = strValue
	local path = system.pathForFile( theFile, system.DocumentsDirectory )
	-- io.open opens a file at path. returns nil if no file found
	local file = io.open( path, "w+" )
	if file then
		-- write game score to the text file
		file:write( theValue )
		io.close( file )
	end
end


local loadValue = function( strFilename )
	-- will load specified file, or create new file if it doesn'texist
	local theFile = strFilename
	local path = system.pathForFile( theFile, system.DocumentsDirectory )
	-- io.open opens a file at path. returns nil if no file found
	local file = io.open( path, "r" )
	if file then
		-- read all contents of file into a string
		local contents = file:read( "*a" )
		io.close( file )
		return contents
	else
		-- create file b/c it doesn't exist yet
		file = io.open( path, "w" )
		file:write( "0" )
		io.close( file )
		return "0"
	end
end

-- Called when the scene's view does not exist:
function scene:createScene( event )
local gameGroup = self.view
-- completely remove loadgame's view
storyboard.removeScene( "loadgame" )
print( "\nmaingame: createScene event")
end



function scene:enterScene( event )
		local gameGroup = self.view

		local setScore = function( scoreNum )
			local newScore = scoreNum
			gameScore = newScore
			if (gameScore < 0) then 
				gameScore = 0; 
			end
			scoreText.text = "Score: " .. gameScore
			scoreText.xScale = 0.5; scoreText.yScale = 0.5
			scoreText.x = (scoreText.contentWidth * 0.5) + 15
			scoreText.y = 15
		end

		local moveLeft = function(event)
			if event.phase=="began" then
					charObject:setSequence( "leftrun" )
					charObject:play()
					motionx = -speed
			end	
			if event.phase=="ended" then
				charObject:setSequence( "standleft" )
				--player:play()
			end	
		end
				local stop = function(event)
			if event.phase=="ended" then
				motionx = 0
			end
		end

		local movePlayer = function(event)
			charObject.x=charObject.x + motionx
		end




		local moveRight = function(event)
			if event.phase=="began" then
					charObject:setSequence( "rightrun" )
					charObject:play()
					motionx = speed
			end	
			if event.phase=="ended" then
				charObject:setSequence( "standright" )
				--player:play()
			end		
			
		end


		local allowJump = function(event)
			if(event.object1.myName=="level55" and event.object2.myName=="character1") then
				charInAir=false
			end
			if(event.object1.myName=="powerUp" and event.object2.myName=="character1") then
				charInAir=false
			end
			if(event.object2.myName=="powerUp" and event.object1.myName=="character1") then
				charInAir=false
			end
		end





		local moveUp = function(event)
			if(event.phase == "began" and charInAir == false) then
				charInAir = true
				--player:setSequence( "jumpright" )
				--	player:play()
				charObject:setLinearVelocity( 0, -180 )
			end
		end

		local callGameOver = function()
			--audio.play( gameOverSound )
			gameIsActive = false
			physics.pause()
			audio.pause( 1 )
			audio.pause( 2 )
			pauseBtn.isVisible = false
			pauseBtn.isActive = false
			shade = display.newRect( 0, 0, 570, 320 )
			shade:setFillColor( 0, 0, 0, 255 )
			shade.x = 240; shade.y = 160
			shade.alpha = 0
			gameOverScreen = display.newImageRect( "gameOver1.png", 400,300 )
			local newScore = gameScore
			setScore( newScore )
			gameOverScreen.x = 240; gameOverScreen.y = 160
			gameOverScreen.alpha = 0
			gameGroup:insert( shade )
			gameGroup:insert( gameOverScreen )
			transition.to( shade, { time=200, alpha=0.65 } )
			transition.to( gameOverScreen, { time=500, alpha=1 } )
			scoreText:setTextColor( 0, 0, 0 )
			scoreText.isVisible = false
			scoreText.text = "Score: " .. gameScore
			scoreText.xScale = 0.5; scoreText.yScale = 0.5 
			scoreText.x = 240
			scoreText.y = 160
			scoreText:toFront()
			timer.performWithDelay( 0,function() scoreText.isVisible = true; end, 1 )
			if gameScore > highScore then
					highScore = gameScore
					local highScoreFilename = "highScore.data"
					saveValue( highScoreFilename, tostring(highScore) )
			end
			highScoreText = display.newText( "Best Game Score: " ..tostring( highScore ), 0, 0, "Arial", 30 )
			highScoreText:setTextColor( 0, 0, 0 )
			highScoreText.xScale = 0.5; highScoreText.yScale = 0.5
			highScoreText.x = 240
			highScoreText.y = 120
			gameGroup:insert( highScoreText )
			local onMenuTouch = function( event )
				if event.phase == "release" then
					
					audio.play( btnSound )
					storyboard.removeScene( "maingame" )
					storyboard.gotoScene( "mainmenu", "fade", 500 )
				end
			end
			menuBtn = ui.newButton{
			defaultSrc = "menubtn.png",
			defaultX = 60,
			defaultY = 60,
			overSrc = "menubtn-over.png",
			overX = 60,
			overY = 60,
			onEvent = onMenuTouch,
			id = "MenuButton",
			text = "",
			font = "Helvetica",
			textColor = { 255, 255, 255, 255 },
			size = 16,
			emboss = false
			}
			menuBtn.x = 100; menuBtn.y = 260
			gameGroup:insert( menuBtn )

			local onFBTouch = function( event )
				if event.phase == "release" then
					local fbAppID = "xxxxxxxxxxxxxx"	
					local facebookListener = function( event )
							if ( "session" == event.type ) then			
								if ( "login" == event.phase ) then	
									local theMessage = "Got a score of " .. gameScore .. " Stickman Galileo!"		   
									facebook.request( "me/feed", "POST", {
										message=theMessage,
										name="Stickman Galileo",
										caption="Download and compete with me!"})
									
								end
							end
					end
					facebook.login( fbAppID, facebookListener, { "publish_stream" } )
				end
			end

			fbBtn = ui.newButton{
				defaultSrc = "facebookbtn.png",
				defaultX = 80,
				defaultY = 80,
				overSrc = "facebookbtn-over.png",
				overX = 80,
				overY = 80,
				onEvent = onFBTouch,
			}
			fbBtn.x = 260; fbBtn.y = 260
			gameGroup:insert(fbBtn)
		end

		local livesCount = function()
			gameLives = gameLives - 1
			livesText.text = "Lives: " .. gameLives
			livesText.xScale = 0.5; livesText.yScale = 0.5
			livesText.x = (480 - (livesText.contentWidth * 0.5)) - 15
			livesText.y = 15
			
			if (gameLives < 1) then
				callGameOver()
			end
		end

		local rotateHand = function(playerHand, angle)
			if(angle~=nil) then
				playerHand.rotation = -angle
			end
		end

		local touchManager = function(event)
				if (event.phase == "cancelled" or event.phase == "ended") then
					dpadMgr.destroy(dpad)
					dpad = nil
					motionx=0
					gameGroup:remove(dpad)
				end

				if (event.phase == "began" and dpad == nil) then
					
					dpad = dpadMgr.create(event.x, event.y)
					dpad.isVisible = true
					gameGroup:insert( dpad)
				end

				if (dpad ~= nil) then
			
					angle= dpadMgr.getAngle(dpad, event)
					if(angle==nil) then
						angle=angleOld
					end
					if(not (angle>=200 and angle<=350)) then
						angleBullet=angle
						rotateHand(charObjectHand, angle)
					end
					angleOld=angle
				end
				
		end

		local shoot = function(event)
				local bullet = display.newImage( "bullet.png" )
				
				bullet.name="bullet"
				bullet.x=charObjectHand.x+40
				bullet.y=charObjectHand.y-20
				physics.addBody( bullet,"dynamic",physicsData1:get("bullet") )
				bullet.gravityScale = 0
				bullet.isFixedRotation = true
				bullet.angle=angleBullet
				local forces = forcesByAngle(250, bullet.angle)
				bullet:setLinearVelocity(forces.x, forces.y)
				audio.play(shotsnd , {channel=2})
				bullets.insert(bullets,bullet)

		end
		local refreshShooting=function( )
			if(startShoot~=nil) then
				timer.cancel(startShoot)
			end
		end
		local shootTimer = function(event)
			if(event.phase=="began") then

				refreshShooting()
				startShoot = timer.performWithDelay( 500, shoot , 0 )
			end
			if(event.phase=="ended") then
				timer.cancel( startShoot )
			end

		end


		function collisionBulletWithWorld(event)
				if(event.object1.myName=="level55" and event.object2.name=="bullet") then
					bullets:remove(event.object2)
				end
		end

		function collisionBulletWithEnemy(event)
				if(event.object1.myName=="enemy" and event.object2.name=="bullet") then
	 				audio.play(bloodSplat , {channel=1})
					bullets:remove(event.object2)

					deadenemy.x=event.object1.x
					deadenemy.y=event.object1.y
					deadenemy.isVisible=true
					deadenemy:setSequence( "Dying" )
					deadenemy:play()
					event.object1:removeSelf( )
					local newScore = gameScore + 10
					setScore( newScore )
				end
				if(event.object2.myName=="enemy" and event.object1.name=="bullet") then
					audio.play(bloodSplat ,{channel=1})
					bullets:remove(event.object1)
					event.object2:removeSelf( )
					local newScore = gameScore + 10
					setScore( newScore )
				end
		end
		function collisionBulletWithPowerUp(event)
				if(event.object1.myName=="powerUp" and event.object2.name=="bullet") then
					audio.play(powerlife , {channel=3})
					bullets:remove(event.object2)
					event.object1:removeSelf( )
					gameLives=20
					livesText.text = "Lives: " .. gameLives
					livesText.xScale = 0.5; livesText.yScale = 0.5 
					livesText.x = (480 - (livesText.contentWidth * 0.5)) - 15
					livesText.y = 15
				
				elseif(event.object2.myName=="powerUp" and event.object1.name=="bullet") then
					bullets:remove(event.object1)
					event.object2:removeSelf( )
					gameLives=20
					livesText.text = "Lives: " .. gameLives
					livesText.xScale = 0.5; livesText.yScale = 0.5 
					livesText.x = (480 - (livesText.contentWidth * 0.5)) - 15
					livesText.y = 15
				
				elseif(event.object1.myName=="powerUp" and event.object2.myName=="level55") then
					event.object1:setSequence( "crate" )
				
				elseif(event.object2.myName=="powerUp" and event.object1.myName=="level55") then
					event.object2:setSequence( "crate" )
				end
		end

	local enemySpawn = function()

			local sheetData = { width=64, height=55, numFrames=14, sheetContentWidth=448, sheetContentHeight=110}
			local mySheet = graphics.newImageSheet( "tester.png", sheetData )
			local sequenceData = 
				{
	  				{ name = "RRun",frames={1,2,3,4,5,6,7}, time=1000, loopCount=0},
	  				{ name = "LRun",frames={14,13,12,11,10,9,8}, time=1000, loopCount=0}  
 				
				}
			local enemy = display.newSprite( mySheet, sequenceData )
			enemy.x= math.random(-150,1000)
			enemy.y=-100
			enemy.isOnGround=false
			enemy.myName="enemy"
			local enemyFilter = { categoryBits = 8, maskBits = 213, groupIndex = 0 } 
			local enemyBody = { friction=0.4, bounce=0, bodyType="dynamic",filter=enemyFilter} 
			physics.addBody( enemy,enemyBody)
			enemy.isFixedRotation=true
			enemy.speed=3
			enemy.isMoving=false
			enemy.direction=""
			enemies.insert( enemies,enemy )			
			camera:add(enemies,6,false)

			
		end
			
		local createdeadenemy=function()
		


			local enemyDeadData = { width=64, height=55, numFrames=56, sheetContentWidth=448, sheetContentHeight=512}
			local mySheetDeadenemy = graphics.newImageSheet( "zombie.png",  enemyDeadData )
			local deadSequenceData = {{ name = "Dying",frames={50,51,52,53,54,55,56}, time=1000, loopCount=1}}
			 deadenemy = display.newSprite( mySheetDeadenemy, deadSequenceData )
			deadenemy.isVisible=false
			camera:add(deadenemy,7,false)

		end
		local moveEnemy = function()
				for i=1,enemies.numChildren,1 do

					if (enemies[i].x > charObject.x) then
						enemies[i].speed= -1
						if(enemies[i].isMoving==false) then
							enemies[i]:setSequence( "LRun" )
							enemies[i].direction="left"
							enemies[i]:play()
							enemies[i].isMoving=true
						end
						if(enemies[i].isMoving==true and enemies[i].direction=="right") then
							enemies[i]:setSequence( "LRun" )
							enemies[i].direction="left"
							enemies[i]:play()
						end

					end	

					if (enemies[i].x < charObject.x) then
						enemies[i].speed= 1
						if(enemies[i].isMoving==false) then
							enemies[i]:setSequence( "RRun" )
							enemies[i].direction="right"
							enemies[i]:play()
							enemies[i].isMoving=true
						end
						if(enemies[i].isMoving==true and enemies[i].direction=="left") then
							enemies[i]:setSequence( "RRun" )
							enemies[i].direction="right"
							enemies[i]:play()
						end 
					end
				enemies[i].x = enemies[i].x + enemies[i].speed
			end
		end



		local enemyTimer = function()
				startEnemy = timer.performWithDelay( 1000, enemySpawn, 0 )
		end
	local powerUpSpawn = function()
			local sheetData = { width=75, height=110, numFrames=1, sheetContentWidth=75, sheetContentHeight=110}
			local mySheet = graphics.newImageSheet( "paralife.png", sheetData )
			local mySheet2 = graphics.newImageSheet( "lifeCrate.png", sheetData )
			local sequenceData = 
				{
	  				{ name = "para" , sheet=mySheet,frames={1},loopCount=0},
	  				{ name = "crate" , sheet=mySheet2,frames={1},loopCount=0}
 				
				}
			local powerUp = display.newSprite( mySheet,sequenceData)
			powerUp.x= math.random(-150,1000)
			powerUp.y=-100
			powerUp.myName="powerUp"
			physics.addBody( powerUp, physicsData2:get("paralife") )
			powerUp.linearDamping =10
			powerUp.angularDmping = 10
			powerUps.insert( powerUps,powerUp )
			camera:add(powerUps,6,false)
		end
			
		local powerUpTimer = function()
				startPowerUp = timer.performWithDelay( 10000, powerUpSpawn, 0 )
		end
		local hud = function()
			
			livesText = display.newText( "Lives: " .. gameLives, 0, 0,"Arial", 45 )
			livesText:setTextColor( 255, 255, 255, 255 ) 
			livesText.xScale = 0.5; livesText.yScale = 0.5
			livesText.x = (480 - (livesText.contentWidth * 0.5)) - 15
			livesText.y = 15
			gameGroup:insert( livesText )
			scoreText = display.newText( "Score: " .. gameScore, 0, 0,"Arial", 45 )
			scoreText:setTextColor( 255, 255, 255, 255 ) 
			scoreText.xScale = 0.5; scoreText.yScale = 0.5 
			scoreText.x = (scoreText.contentWidth * 0.5) + 15
			scoreText.y = 15
			gameGroup:insert( scoreText )
			musicbtnon=display.newImage("music_on.png")
			musicbtnon.x=280
			musicbtnon.y=19
			musicbtnon.isVisible=true
			musicbtnon.isActive = true
			gameGroup:insert( musicbtnon )
			musicbtnoff=display.newImage("music_off.png")
			musicbtnoff.x=280
			musicbtnoff.y=19
			musicbtnoff.isVisible=false
			musicbtnoff.isActive = false
			gameGroup:insert( musicbtnoff )

			local onPauseTouch = function( event )
					if event.phase == "release" and pauseBtn.isActive then
						audio.play( btnSound )
						if gameIsActive then
						
							gameIsActive = false
							physics.pause()
							Runtime:removeEventListener("enterFrame",moveEnemy)

							leftarrow:removeEventListener( "touch", moveLeft )
							rightarrow:removeEventListener("touch", moveRight)

							Runtime:removeEventListener("collision",allowJump)

							uparrow:removeEventListener( "touch", moveUp)

							Runtime:removeEventListener( "touch", stop)

							Runtime:removeEventListener("enterFrame",movePlayer)

							dpadScreen:removeEventListener("touch", touchManager)

							dpadScreen:removeEventListener( "touch", shootTimer )

							Runtime:removeEventListener("collision",collisionBulletWithWorld)

							Runtime:removeEventListener("collision",collisionBulletWithEnemy)

							Runtime:removeEventListener("collision",collisionPlayerWithEnemy)

							Runtime:removeEventListener("collision",collisionBulletWithPowerUp)
							
							function pauseGame()
				                timer.pause( startEnemy )
				                timer.pause(startPowerUp)
				                print("timer has been paused")
				            end
				            timer.performWithDelay(1, pauseGame)
				   
							if not shade then
								shade = display.newRect( 0, 0, 570, 380 )
								shade:setFillColor( 0, 0, 0, 255 )
								shade.x = 240; shade.y = 160
								gameGroup:insert( shade )
							end
							shade.alpha = 0.5
							
							if pauseBG then
								pauseBG.isVisible = true
								pauseBG.isActive = true
								pauseBG:toFront()
							end
							
							pauseBtn:toFront()

						else
							
							if shade then
								display.remove( shade )
								shade = nil
							end
							
							
							if pauseBG then
								pauseBG.isVisible = false
								pauseBG.isActive = false
							end
							
							gameIsActive = true
							physics.start()
							Runtime:addEventListener("enterFrame",moveEnemy)
							leftarrow:addEventListener("touch", moveLeft)
							rightarrow:addEventListener("touch", moveRight)
							Runtime:addEventListener("collision",allowJump)
							uparrow:addEventListener( "touch", moveUp)
							Runtime:addEventListener( "touch", stop)
							Runtime:addEventListener("enterFrame",movePlayer)
							dpadScreen:addEventListener("touch", touchManager)
							dpadScreen:addEventListener( "touch", shootTimer)
							Runtime:addEventListener("collision",collisionBulletWithWorld)
							Runtime:addEventListener("collision",collisionBulletWithEnemy)
							Runtime:addEventListener("collision",collisionPlayerWithEnemy)
							Runtime:addEventListener("collision",collisionBulletWithPowerUp)
							
							local function resumeGame()
								audio.resume( 1 )
								audio.resume( 2 )
				                timer.resume( startEnemy )
				                timer.resume( startPowerUp )
				                print("timer has been resumed")
				            end
				            timer.performWithDelay(1, resumeGame)
				
						end
					end
				end
				
				pauseBtn = ui.newButton{
					defaultSrc = "pausebtn.png",
					defaultX = 44,
					defaultY = 44,
					overSrc = "pausebtn-over.png",
					overX = 44,
					overY = 44,
					onEvent = onPauseTouch,
					id = "PauseButton",
					text = "",
					font = "Helvetica",
					textColor = { 255, 255, 255, 255 },
					size = 16,
					emboss = false
				}


				
				
				pauseBtn.x = 250; pauseBtn.y = 288
				pauseBtn.isVisible = false
				pauseBtn.isActive = false
				
				gameGroup:insert( pauseBtn )
				
				pauseBG = display.newImageRect( "pauseoverlay.png", 570, 380 )
				pauseBG.x = 240; pauseBG.y = 160
				pauseBG.isVisible = false
				pauseBG.isActive = false
				
				gameGroup:insert( pauseBG )
		end

		local gameActivate = function()
			gameIsActive = true
			pauseBtn.isVisible = true
			pauseBtn.isActive = true
		end


		local drawBackground = function()
			background = display.newImage( "bg.png", 0, 0, true )
			background.x = display.contentWidth/2
			background.y = display.contentHeight/2
			gameGroup:insert(background)

			ground = display.newImage("level1.png")
			ground.x = display.contentWidth
			ground.y = display.contentHeight/2+100
			ground.myName = "level55"
			groundFilter = { categoryBits = 4, maskBits = 249,groupIndex = 0 } 
			groundBody = { friction=20, bounce=0, bodyType="static", filter=groundFilter }
			physics.addBody( ground,"static", groundBody )
			gameGroup:insert(ground)

			groundLeft = display.newRect(-230, 50, 10, 200 )
			groundLeft.myName = "level55"
			groundLeft:setFillColor( 0,200,0 )
			groundLeftFilter = { categoryBits = 128, maskBits = 61,groupIndex = 0 } 
			groundLeftBody = { friction=10, bounce=0, bodyType="static", filter=groundLeftFilter }
			physics.addBody( groundLeft,"static" )
			gameGroup:insert(groundLeft)

			groundRight = display.newRect(1100, 50, 10, 200 )
			groundRight.myName = "level55"
			groundRight:setFillColor( 0,200,0 )
			groundRightFilter = { categoryBits = 64, maskBits = 61,groupIndex = 0 } 
			groundRightBody = { friction=10, bounce=0, bodyType="static", filter=groundRightFilter }
			physics.addBody( groundRight,"static" )
			gameGroup:insert(groundRight)
		end	


		local createChar = function()
			
			playerSheetData = {width=32,height=32.5,numFrames=18,sheetContentWidth=64,sheetContentHeight=306}
			playerSheet = graphics.newImageSheet( "move.png", playerSheetData )
			playerSequenceData=
			{
				{name="rightrun",start=1,count=6,time=800,loopCount=0},
				{name="leftrun",frames={7,8,9,10,11,12},time=800},
				{name="standleft",frames={14}},
				{name="standright",frames={13}},
				{name="jumpright",frames={15,16},time=400,loopCount=0},
				{name="jumpleft",frames={17,18},time=400,loopCount=0}
			}
			charObject=display.newSprite(playerSheet,playerSequenceData)
			charObject.x=120
			charObject.y=200
			charObject.myName = "character1"
			charObjectFilter = { categoryBits = 1, maskBits = 237,groupIndex = 0 } 
			charObjectBody = { friction=0.4, bounce=0,density=10, bodyType="dynamic", filter=charObjectFilter }
			physics.addBody( charObject, charObjectBody )
			charObject.isFixedRotation = true
			charObject:setSequence( "standright" )
			gameGroup:insert(charObject)


			charObjectHand=display.newImage("gun.png")
			charObjectHand.x=charObject.x+30
			charObjectHand.y=200
			charObjectHand.myName = "hand"
			charObjectHandFilter = { categoryBits = 2, maskBits = 2,groupIndex = 0 } 
			charObjectHandBody = { friction=0.4, bounce=0, bodyType="dynamic", filter=charObjectHandFilter }
			physics.addBody(charObjectHand,charObjectHandBody)
			charObjectHand.gravityScale = 0
			charObjectHand.isFixedRotation = true
			gameGroup:insert(charObjectHand)


			myJoint = physics.newJoint( "pivot", charObject, charObjectHand,charObject.x,charObject.y )
			myJoint.isLimitEnabled = true
			myJoint:setRotationLimits( -45, 45 )
		end	

		function collisionPlayerWithEnemy(event)
				if(event.object2.myName=="enemy" and (event.object1.myName == "character1" or event.object1.myName=="hand")) then
					event.object2:removeSelf( )

					livesCount()
				end
				if(event.object1.myName=="enemy" and (event.object2.myName == "character1" or event.object2.myName=="hand")) then
					event.object1:removeSelf( )
					livesCount()
				end
		end



		local createJoystick = function()

			leftarrow = display.newImage("L_arrow.png")
			leftarrow.x=350
			leftarrow.y=280
			leftarrow:toFront( )

			rightarrow = display.newImage("R_arrow.png")
			rightarrow.x=450
			rightarrow.y=280
			rightarrow:toFront( )

			uparrow = display.newImage("U_arrow.png")
			uparrow.x=400
			uparrow.y=240
			uparrow:toFront( )

			dpadScreen = display.newImage( "dpadScreen.png" ,0,0,true )
			dpadScreen.x=display.contentWidth/8
			dpadScreen.y=display.contentHeight/2
			gameGroup:insert(leftarrow)
			gameGroup:insert(rightarrow)
			gameGroup:insert(uparrow)
			gameGroup:insert(dpadScreen)
		end




		local destroyEverything = function()
				dpadMgr.destroy(dpad)
				dpad = nil
				dpadMgr.destroyMgr()
				dpadMgr = nil
		end

		local createCamera = function()
				camera:add(charObject, 1, false)
				camera:add(ground, 2, false)
				camera:add(bullets,3,false)
				camera:add(charObjectHand,4,false)
				camera:add(groundLeft,5,false)
				camera:add(groundRight,5,false)
				camera.x = charObject.x/2-30
				camera.y = charObject.y/2-250
				camera:setFocus(charObject)
				camera:setBounds(120,800,1,0)
				camera.damping=0
				camera:track()
				gameGroup:insert(camera)
		end	 

		local enemyTimer = function()
				startEnemy = timer.performWithDelay( 1000, enemySpawn, 0 )
		end

		local gameStart = function()
			backgrndmusic = audio.loadSound("track1.mp3")
			audio.setVolume( 0.1, { channel=4 } )
			audio.play( backgrndmusic , {channel=4,loops=-1}  )
			zombieMoan=audio.loadSound("zombieMoan.mp3")
			audio.setVolume( 0.1, { channel=5 } )
			audio.play( zombieMoan , {channel=5,loops=-1}  )
			local highScoreFilename = "highScore.data"
			local loadedHighScore = loadValue( highScoreFilename )
			highScore = tonumber(loadedHighScore)
			physics.start()
			drawBackground()
			createChar()
			enemyTimer()
			createdeadenemy()
			powerUpTimer()
			createCamera()
			hud()
			gameActivate()
			createJoystick()
			leftarrow:addEventListener("touch", moveLeft)
			rightarrow:addEventListener("touch", moveRight)
			Runtime:addEventListener("collision",allowJump)
			uparrow:addEventListener( "touch", moveUp)
			Runtime:addEventListener( "touch", stop)
			Runtime:addEventListener("enterFrame",movePlayer)
			dpadScreen:addEventListener("touch", touchManager)
			dpadScreen:addEventListener( "touch", shootTimer )
			Runtime:addEventListener("collision",collisionBulletWithWorld)
			Runtime:addEventListener("collision",collisionBulletWithEnemy)
			Runtime:addEventListener("collision",collisionPlayerWithEnemy)
			Runtime:addEventListener("collision",collisionBulletWithPowerUp)
			Runtime:addEventListener("enterFrame",moveEnemy)
		end

		gameStart()
		print( "maingame: enterScene event" )

end

function scene:exitScene( event )
	physics.stop()
	Runtime:removeEventListener("collision",allowJump)
	Runtime:removeEventListener("collision",collisionBulletWithWorld)
	Runtime:removeEventListener("collision",collisionBulletWithEnemy)
	Runtime:removeEventListener("collision",collisionPlayerWithEnemy)
	Runtime:removeEventListener("collision",collisionBulletWithPowerUp)
	print( "maingame: exitScene event" )
	camera:destroy()
end

function scene:destroyScene( event)
	print( "((destroying maingame's view))" )
	physics.stop()
	Runtime:removeEventListener("collision",allowJump)
	Runtime:removeEventListener("collision",collisionBulletWithWorld)
	Runtime:removeEventListener("collision",collisionBulletWithEnemy)
	Runtime:removeEventListener("collision",collisionBulletWithPowerUp)
	Runtime:removeEventListener("collision",collisionPlayerWithEnemy)
	timer.cancel( startEnemy )
	timer.cancel( startShoot )
	timer.cancel( startPowerUp )
	audio.stop( 1 )
end

scene:addEventListener( "createScene", scene )
scene:addEventListener( "enterScene", scene )
scene:addEventListener( "exitScene", scene )
scene:addEventListener( "destroyScene", scene )
return scene
	