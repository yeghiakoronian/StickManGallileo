---------------------------------------------------------------------------------
--
-- mainmenu.lua
--
---------------------------------------------------------------------------------

local storyboard = require( "storyboard" )
local scene = storyboard.newScene()
tm = require("transitionManager")
tm = tm.new()
local ui = require("ui")

---------------------------------------------------------------------------------
-- BEGINNING OF YOUR IMPLEMENTATION
---------------------------------------------------------------------------------

local btnAnim

local btnSound = audio.loadSound( "btnSound.wav" )

-- Called when the scene's view does not exist:
function scene:createScene( event )
	local screenGroup = self.view
	
	-- completely remove maingame and options
	storyboard.removeScene( "maingame" )
	storyboard.removeScene( "options" )

	
	print( "\nmainmenu: createScene event" )
end


-- Called immediately after scene has moved onscreen:
function scene:enterScene( event )
	local screenGroup = self.view
	



	
	print( "mainmenu: enterScene event" )
	
	local backgroundImage = display.newImageRect( "mainMenuBG.png", 480, 320 )
	


	backgroundImage.x = 240; backgroundImage.y = 160
	screenGroup:insert( backgroundImage )
	
	local playBtn
	
	local onPlayTouch = function( event )
		if event.phase == "release" then
			
			audio.play( btnSound )
			storyboard.gotoScene( "loadgame", "fade", 300  )
			
		end
	end
	
	playBtn = ui.newButton{
		defaultSrc = "stickbu.png",
		defaultX = 100,
		defaultY = 30,
		overSrc = "stickbu1.png",
		overX = 100,
		overY = 30,
		onEvent = onPlayTouch,
		id = "PlayButton",
		text = "",
		font = "Helvetica",
		textColor = { 255, 255, 255, 255 },
		size = 16,
		emboss = false
	}
	
	playBtn.x = 200; playBtn.y = 440
  	screenGroup:insert( playBtn )
	
	btnAnim = transition.to( playBtn, { time=500, y=260, transition=easing.inOutExpo } )
	
	
	local optBtn
	
	local onOptionsTouch = function( event )
		if event.phase == "release" then
			
			audio.play( btnSound )
			storyboard.gotoScene( "options", "crossFade", 300  )
			
		end
	end
	
	optBtn = ui.newButton{
		defaultSrc = "optbtn.png",
		defaultX = 60,
		defaultY = 60,
		overSrc = "optbtn-over.png",
		overX = 60,
		overY = 60,
		onEvent = onOptionsTouch,
		id = "OptionsButton",
		text = "",
		font = "Helvetica",
		textColor = { 255, 255, 255, 255 },
		size = 16,
		emboss = false
	}
	
	optBtn.x = 430; optBtn.y = 440
  	screenGroup:insert( optBtn )
	
	btnAnim = transition.to( optBtn, { time=500, y=280, transition=easing.inOutExpo } )



	local credits = display.newImage("creditsImg.png")
		screenGroup:insert(credits)
		credits.x, credits.y = -(credits.width/2-30), display.contentHeight/2

		local rect_width, rect_height = 30, 80
		local credits_rect = display.newRect(0, display.contentHeight/2-rect_height/2, rect_width, rect_height)
		screenGroup:insert(credits_rect)
		credits_rect.alpha = 0.01
		
		local opencredits = function(event)
			if (event.phase=="ended" and not credits.tm ) then
				if (credits.x~=display.contentWidth/2 ) then
					audio.play( btnSound )
					credits.tm = tm:add(credits, {time=1000, x=display.contentWidth/2, onComplete=function() credits.tm = nil end})
					display.getCurrentStage():setFocus(credits)
				end
			end
		end
		credits_rect:addEventListener("touch", opencredits)


		--close
		local closecredits = function(event)

			if (event.phase=="ended" and not credits.tm ) then
					if (credits.x==display.contentWidth/2) then
							audio.play( btnSound )
							credits.tm = tm:add(credits, {time=1000, x=-(credits.width/2-30), onComplete=function() credits.tm = nil display.getCurrentStage():setFocus(nil) end})
					end
			end				

		end
		credits:addEventListener("touch", closecredits)
	
end









-- Called when scene is about to move offscreen:
function scene:exitScene()

	if btnAnim then transition.cancel( btnAnim ); end
	
	print( "mainmenu: exitScene event" )

end


-- Called prior to the removal of scene's "view" (display group)
function scene:destroyScene( event )
	
	print( "((destroying mainmenu's view))" )
end

---------------------------------------------------------------------------------
-- END OF YOUR IMPLEMENTATION
---------------------------------------------------------------------------------

-- "createScene" event is dispatched if scene's view does not exist
scene:addEventListener( "createScene", scene )

-- "enterScene" event is dispatched whenever scene transition has finished
scene:addEventListener( "enterScene", scene )

-- "exitScene" event is dispatched before next scene's transition begins
scene:addEventListener( "exitScene", scene )

-- "destroyScene" event is dispatched before view is unloaded, which can be
scene:addEventListener( "destroyScene", scene )

---------------------------------------------------------------------------------

return scene