
--local gameGroup = display.newGroup()
system.activate( "multitouch" )
local storyboard = require( "storyboard" )
local scene = storyboard.newScene()
local facebook = require "facebook"
local sprite = require "sprite"
local physics = require "physics"
Vector2D = require "Vector2D"
require "auxFunctions"
local dpadMgr = require "dpad"
local ui = require "ui"
local perspective=require("perspective")
local camera=perspective.createView()
local dpad = nil
local angleOld = 0
local angleBullet = 0

local charObject
local charObjectHand
local playerSheetData
local playerSheet
local playerSequenceData
--local enemy

local motionx = 0
local speed = 5
local charInAir = true
local leftarrow
local uparrow
local rightarrow
local background
local dpadScreen
local ground
local bullets = display.newGroup( )
local physicsData = (require "level1").physicsData(1.0)
local physicsData1 = (require "bullet1").physicsData(1.0)
_G.W = display.contentWidth
_G.H = display.contentHeight

local startEnemy
local gameScore = 0
local scoreText
local highScoreText
local highScoreame
local gameLives = 20

local gameIsActive = false
local livesText

local pauseBtn
local pauseMenuBtn
local pauseBG
local menuBtn
local fbBtn
local btnSound = audio.loadSound( "btnSound.wav" )

local saveValue = function( strFilename, strValue )
	-- will save specified value to specified file
	local theFile = strFilename
	local theValue = strValue
	local path = system.pathForFile( theFile, system.DocumentsDirectory )
	-- io.open opens a file at path. returns nil if no file found
	local file = io.open( path, "w+" )
	if file then
		-- write game score to the text file
		file:write( theValue )
		io.close( file )
	end
end


local loadValue = function( strFilename )
	-- will load specified file, or create new file if it doesn'texist
	local theFile = strFilename
	local path = system.pathForFile( theFile, system.DocumentsDirectory )
	-- io.open opens a file at path. returns nil if no file found
	local file = io.open( path, "r" )
	if file then
		-- read all contents of file into a string
		local contents = file:read( "*a" )
		io.close( file )
		return contents
	else
		-- create file b/c it doesn't exist yet
		file = io.open( path, "w" )
		file:write( "0" )
		io.close( file )
		return "0"
	end
end

-- Called when the scene's view does not exist:
function scene:createScene( event )
local gameGroup = self.view
-- completely remove loadgame's view
storyboard.removeScene( "loadgame" )
print( "\nmaingame: createScene event")
end



function scene:enterScene( event )
		local gameGroup = self.view

		local setScore = function( scoreNum )
			local newScore = scoreNum
			gameScore = newScore
			if (gameScore < 0) then 
				gameScore = 0; 
			end
			scoreText.text = "Score: " .. gameScore
			scoreText.xScale = 0.5; scoreText.yScale = 0.5
			scoreText.x = (scoreText.contentWidth * 0.5) + 15
			scoreText.y = 15
		end

		local moveLeft = function(event)
			if event.phase=="began" then
					charObject:setSequence( "leftrun" )
					charObject:play()
					motionx = -speed
			end	
			if event.phase=="ended" then
				charObject:setSequence( "standleft" )
				--player:play()
			end	
		end
				local stop = function(event)
			if event.phase=="ended" then
				motionx = 0
			end
		end

		local movePlayer = function(event)
			charObject.x=charObject.x + motionx
		end




		local moveRight = function(event)
			if event.phase=="began" then
					charObject:setSequence( "rightrun" )
					charObject:play()
					motionx = speed
			end	
			if event.phase=="ended" then
				charObject:setSequence( "standright" )
				--player:play()
			end		
			
		end


		local allowJump = function(event)
			if(event.object1.myName=="level55" and event.object2.myName=="character1") then
				charInAir=false
			end
		end





		local moveUp = function(event)
			if(event.phase == "began" and charInAir == false) then
				charInAir = true
				--player:setSequence( "jumpright" )
				--	player:play()
				charObject:setLinearVelocity( 0, -180 )
			end
		end

		local callGameOver = function()
			--audio.play( gameOverSound )
			gameIsActive = false
			physics.pause()
			--leftarrow:removeEventListener( "touch", moveLeft )
			--rightarrow:removeEventListener("touch", moveRight)
			--Runtime:removeEventListener("collision",allowJump)
			--uparrow:removeEventListener( "touch", moveUp)
			--Runtime:removeEventListener( "touch", stop)
			--Runtime:removeEventListener("enterFrame",movePlayer)
			--dpadScreen:removeEventListener("touch", touchManager)
			--dpadScreen:removeEventListener( "touch", shoot )
			--Runtime:removeEventListener('enterFrame',updateBullets)
			--Runtime:removeEventListener("collision",collisionBulletWithWorld)
		   -- dpadScreen:removeEventListener( "touch", shooting )
			pauseBtn.isVisible = false
			pauseBtn.isActive = false
			shade = display.newRect( 0, 0, 570, 320 )
			shade:setFillColor( 0, 0, 0, 255 )
			shade.x = 240; shade.y = 160
			shade.alpha = 0
			gameOverScreen = display.newImageRect( "gameOver1.png", 400,300 )
			local newScore = gameScore
			setScore( newScore )
			gameOverScreen.x = 240; gameOverScreen.y = 160
			gameOverScreen.alpha = 0
			gameGroup:insert( shade )
			gameGroup:insert( gameOverScreen )
			transition.to( shade, { time=200, alpha=0.65 } )
			transition.to( gameOverScreen, { time=500, alpha=1 } )
			scoreText:setTextColor( 0, 0, 0 )
			scoreText.isVisible = false
			scoreText.text = "Score: " .. gameScore
			scoreText.xScale = 0.5; scoreText.yScale = 0.5 --> forclear retina display text
			scoreText.x = 240
			scoreText.y = 160
			scoreText:toFront()
			timer.performWithDelay( 0,function() scoreText.isVisible = true; end, 1 )
			if gameScore > highScore then
					highScore = gameScore
					local highScoreFilename = "highScore.data"
					saveValue( highScoreFilename, tostring(highScore) )
			end
			highScoreText = display.newText( "Best Game Score: " ..tostring( highScore ), 0, 0, "Arial", 30 )
			highScoreText:setTextColor( 0, 0, 0 )
			highScoreText.xScale = 0.5; highScoreText.yScale = 0.5
			highScoreText.x = 240
			highScoreText.y = 120
			gameGroup:insert( highScoreText )
			local onMenuTouch = function( event )
				if event.phase == "release" then
					
					audio.play( btnSound )
					storyboard.removeScene( "maingame" )
					storyboard.gotoScene( "mainmenu", "fade", 500 )
				end
			end
			menuBtn = ui.newButton{
			defaultSrc = "menubtn.png",
			defaultX = 60,
			defaultY = 60,
			overSrc = "menubtn-over.png",
			overX = 60,
			overY = 60,
			onEvent = onMenuTouch,
			id = "MenuButton",
			text = "",
			font = "Helvetica",
			textColor = { 255, 255, 255, 255 },
			size = 16,
			emboss = false
			}
			menuBtn.x = 100; menuBtn.y = 260
			gameGroup:insert( menuBtn )

			local onFBTouch = function( event )
				if event.phase == "release" then
					local fbAppID = "485051791604007"	--> (string) Your FB App ID from facebook developer's panel
					local facebookListener = function( event )
							if ( "session" == event.type ) then
								-- upon successful login, update their status
								if ( "login" == event.phase ) then	
									local theMessage = "Got a score of " .. gameScore .. " Stickman Galileo!"		   
									facebook.request( "me/feed", "POST", {
										message=theMessage,
										name="Stickman Galileo",
										caption="Download and compete with me!"
										--[[picture="http://www.yoursite.com/yourimage.png"]] } )
										-- The "link" parameter can be the Android Market app link or a website URL of your choosing
								end
							end
					end
					facebook.login( fbAppID, facebookListener, { "publish_stream" } )
				end
			end

			fbBtn = ui.newButton{
				defaultSrc = "facebookbtn.png",
				defaultX = 80,
				defaultY = 80,
				overSrc = "facebookbtn-over.png",
				overX = 80,
				overY = 80,
				onEvent = onFBTouch,
			}
			fbBtn.x = 260; fbBtn.y = 260
			gameGroup:insert(fbBtn)
			--end gameover 
		end

		local livesCount = function()
			gameLives = gameLives - 1
			livesText.text = "Lives: " .. gameLives
			livesText.xScale = 0.5; livesText.yScale = 0.5 --> forclear retina display text
			livesText.x = (480 - (livesText.contentWidth * 0.5)) - 15
			livesText.y = 15
			
			if (gameLives < 1) then
				callGameOver()
			end
		end

		local rotateHand = function(playerHand, angle)
			if(angle~=nil) then
				playerHand.rotation = -angle
			end
		end

		local touchManager = function(event)
				if (event.phase == "cancelled" or event.phase == "ended") then
					dpadMgr.destroy(dpad)
					dpad = nil
					motionx=0
					gameGroup:remove(dpad)
				end

				if (event.phase == "began" and dpad == nil) then
					
					-- Create dpad
					dpad = dpadMgr.create(event.x, event.y)
					dpad.isVisible = true
					gameGroup:insert( dpad)
				end

				if (dpad ~= nil) then
					angle= dpadMgr.getAngle(dpad, event)
					if(angle==nil) then
						angle=angleOld
					end
					if(not (angle>=200 and angle<=350)) then
						angleBullet=angle
						rotateHand(charObjectHand, angle)
					end
					angleOld=angle
				end
				
				return true
		end

		local shoot = function(event)
			if (bullets.numChildren<3 and charObject.isShooting==true ) then
				local bullet = display.newImage( "bullet.png" )
				bullet.name="bullet"
				--livesCount()
				bullet.x=charObjectHand.x+40
				bullet.y=charObjectHand.y-20
				physics.addBody( bullet,"dynamic",physicsData1:get("bullet") )
				bullet.gravityScale = 0
				bullet.isFixedRotation = true
				bullet.angle=angleBullet
				local forces = forcesByAngle(250, bullet.angle)
				bullet:setLinearVelocity(forces.x, forces.y)
				bullets.insert(bullets,bullet)
			end

		end

		local updateBullets = function()
			if(bullets.numChildren~=0) then
				for i = 1 , bullets.numChildren do
					if(pointDistance(bullets[i].x,bullets[i].y,charObjectHand.x,charObjectHand.y)>300)then
						if(bullets.numChildren>1) then
							if(bullets.numChildren==2) then
								bullets:remove(bullets[i-1])
							else
								bullets:remove(bullets[i-2])
							end
						else
							bullets:remove(bullets[i])
						end
					end
				end
			end
		end


		function collisionBulletWithWorld(event)
				if(event.object1.myName=="level55" and event.object2.name=="bullet") then
					bullets:remove(event.object2)
				end
		end

		function collisionBulletWithEnemy(event)
				if(event.object1.myName=="enemy" and event.object2.name=="bullet") then
					bullets:remove(event.object2)
					event.object1:removeSelf( )
					local newScore = gameScore + 10
					setScore( newScore )
				end
				if(event.object2.myName=="enemy" and event.object1.name=="bullet") then
					bullets:remove(event.object1)
					event.object2:removeSelf( )
					local newScore = gameScore + 10
					setScore( newScore )
				end
		end



		function shooting(event)
			if(event.phase=="ended") then
				charObject.isShooting=false
			else
				charObject.isShooting=true
			end
		end



		local hud = function()
			
			livesText = display.newText( "Lives: " .. gameLives, 0, 0,"Arial", 45 )
			livesText:setTextColor( 255, 255, 255, 255 ) --> white
			livesText.xScale = 0.5; livesText.yScale = 0.5 --> forclear retina display text
			livesText.x = (480 - (livesText.contentWidth * 0.5)) - 15
			livesText.y = 15
			gameGroup:insert( livesText )
			scoreText = display.newText( "Score: " .. gameScore, 0, 0,"Arial", 45 )
			scoreText:setTextColor( 255, 255, 255, 255 ) --> white
			scoreText.xScale = 0.5; scoreText.yScale = 0.5 --> forclear retina display text
			scoreText.x = (scoreText.contentWidth * 0.5) + 15
			scoreText.y = 15
			gameGroup:insert( scoreText )
			local onPauseTouch = function( event )
					if event.phase == "release" and pauseBtn.isActive then
						audio.play( btnSound )
						
						-- Pause the game
						
						if gameIsActive then
						
							gameIsActive = false
							physics.pause()
							--leftarrow:removeEventListener( "touch", moveLeft )
							leftarrow:removeEventListener( "touch", moveLeft )
							rightarrow:removeEventListener("touch", moveRight)
							Runtime:removeEventListener("collision",allowJump)
							uparrow:removeEventListener( "touch", moveUp)
							Runtime:removeEventListener( "touch", stop)
							Runtime:removeEventListener("enterFrame",movePlayer)
							dpadScreen:removeEventListener("touch", touchManager)
							dpadScreen:removeEventListener( "touch", shoot )
							Runtime:removeEventListener('enterFrame',updateBullets)
							Runtime:removeEventListener("collision",collisionBulletWithWorld)
							Runtime:removeEventListener("collision",collisionBulletWithEnemy)
							Runtime:removeEventListener("collision",collisionPlayerWithEnemy)
							dpadScreen:removeEventListener( "touch", shooting )
							
							function pauseGame()
				                timer.pause( startEnemy )
				                print("timer has been paused")
				            end
				            timer.performWithDelay(1, pauseGame)
				   
							
							-- SHADE
							if not shade then
								shade = display.newRect( 0, 0, 570, 380 )
								shade:setFillColor( 0, 0, 0, 255 )
								shade.x = 240; shade.y = 160
								gameGroup:insert( shade )
							end
							shade.alpha = 0.5
							
							-- SHOW PAUSE BG
							if pauseBG then
								pauseBG.isVisible = true
								pauseBG.isActive = true
								pauseBG:toFront()
							end
							
							pauseBtn:toFront()

						else
							
							if shade then
								display.remove( shade )
								shade = nil
							end
							
							
							if pauseBG then
								pauseBG.isVisible = false
								pauseBG.isActive = false
							end
							
							gameIsActive = true
							physics.start()
							leftarrow:addEventListener("touch", moveLeft)
							rightarrow:addEventListener("touch", moveRight)
							Runtime:addEventListener("collision",allowJump)
							uparrow:addEventListener( "touch", moveUp)
							Runtime:addEventListener( "touch", stop)
							Runtime:addEventListener("enterFrame",movePlayer)
							dpadScreen:addEventListener("touch", touchManager)
							dpadScreen:addEventListener( "touch", shoot )
							Runtime:addEventListener('enterFrame',updateBullets)
							Runtime:addEventListener("collision",collisionBulletWithWorld)
							Runtime:addEventListener("collision",collisionBulletWithEnemy)
							Runtime:addEventListener("collision",collisionPlayerWithEnemy)
							dpadScreen:addEventListener( "touch", shooting )
							
							local function resumeGame()
				                timer.resume( startEnemy )
				                print("timer has been resumed")
				            end
				            timer.performWithDelay(1, resumeGame)
				
						end
					end
				end
				
				pauseBtn = ui.newButton{
					defaultSrc = "pausebtn.png",
					defaultX = 44,
					defaultY = 44,
					overSrc = "pausebtn-over.png",
					overX = 44,
					overY = 44,
					onEvent = onPauseTouch,
					id = "PauseButton",
					text = "",
					font = "Helvetica",
					textColor = { 255, 255, 255, 255 },
					size = 16,
					emboss = false
				}
				
				pauseBtn.x = 250; pauseBtn.y = 288
				pauseBtn.isVisible = false
				pauseBtn.isActive = false
				
				gameGroup:insert( pauseBtn )
				
				pauseBG = display.newImageRect( "pauseoverlay.png", 570, 380 )
				pauseBG.x = 240; pauseBG.y = 160
				pauseBG.isVisible = false
				pauseBG.isActive = false
				
				gameGroup:insert( pauseBG )
		end

		local gameActivate = function()
			gameIsActive = true
			pauseBtn.isVisible = true
			pauseBtn.isActive = true
		end


		local drawBackground = function()
			background = display.newImage( "bg.png", 0, 0, true )
			background.x = display.contentWidth/2
			background.y = display.contentHeight/2
			gameGroup:insert(background)

			ground = display.newImage("level1.png")
			ground.x = display.contentWidth
			ground.y = display.contentHeight/2+100
			ground.myName = "level55"
			groundFilter = { categoryBits = 1, maskBits = 124,groupIndex = 0 } 
			groundBody = { friction=20, bounce=0, bodyType="static", filter=groundFilter }
			physics.addBody( ground,"static", groundBody )
			gameGroup:insert(ground)

			groundLeft = display.newRect(-230, 50, 10, 200 )
			groundLeft.myName = "level55"
			groundLeft:setFillColor( 0,200,0 )
			groundLeftFilter = { categoryBits = 32, maskBits = 93,groupIndex = 0 } 
			groundLeftBody = { friction=10, bounce=0, bodyType="static", filter=groundLeftFilter }
			physics.addBody( groundLeft,"static" )
			gameGroup:insert(groundLeft)

			groundRight = display.newRect(1100, 50, 10, 200 )
			groundRight.myName = "level55"
			groundRight:setFillColor( 0,200,0 )
			groundRightFilter = { categoryBits = 16, maskBits = 109,groupIndex = 0 } 
			groundRightBody = { friction=10, bounce=0, bodyType="static", filter=groundRightFilter }
			physics.addBody( groundRight,"static" )
			gameGroup:insert(groundRight)
		end	


		local createChar = function()
			
			playerSheetData = {width=32,height=32.5,numFrames=18,sheetContentWidth=64,sheetContentHeight=306}
			playerSheet = graphics.newImageSheet( "move.png", playerSheetData )
			playerSequenceData=
			{
				{name="rightrun",start=1,count=6,time=800,loopCount=0},
				{name="leftrun",frames={7,8,9,10,11,12},time=800},
				{name="standleft",frames={14}},
				{name="standright",frames={13}},
				{name="jumpright",frames={15,16},time=400,loopCount=0},
				{name="jumpleft",frames={17,18},time=400,loopCount=0}
			}
			charObject=display.newSprite(playerSheet,playerSequenceData)
			charObject.x=120
			charObject.y=200
			charObject.isAlive = true
			charObject.isShooting=false
			charObject.myName = "character1"
			charObjectFilter = { categoryBits = 64, maskBits = 53,groupIndex = 0 } 
			charObjectBody = { friction=0.4, bounce=0,density=10, bodyType="dynamic", filter=charObjectFilter }
			physics.addBody( charObject, charObjectBody )
			charObject.isFixedRotation = true
			charObject:setSequence( "standright" )
			gameGroup:insert(charObject)


			charObjectHand=display.newImage("gun.png")
			charObjectHand.x=charObject.x+30
			charObjectHand.y=200
			charObjectHand.myName = "hand"
			charObjectHandFilter = { categoryBits = 2, maskBits = 4,groupIndex = 0 } 
			charObjectHandBody = { friction=0.4, bounce=0, bodyType="dynamic", filter=charObjectHandFilter }
			physics.addBody(charObjectHand,charObjectHandBody)
			charObjectHand.gravityScale = 0
			charObjectHand.isFixedRotation = true
			gameGroup:insert(charObjectHand)


			myJoint = physics.newJoint( "pivot", charObject, charObjectHand,charObject.x,charObject.y )
			myJoint.isLimitEnabled = true
			myJoint:setRotationLimits( -45, 45 )
		end	

		function collisionPlayerWithEnemy(event)
				if(event.object2.myName=="enemy" and (event.object1.myName == "character1" or event.object1.myName=="hand")) then
					event.object2:removeSelf( )

					livesCount()
				end
				if(event.object1.myName=="enemy" and (event.object2.myName == "character1" or event.object2.myName=="hand")) then
					event.object1:removeSelf( )
					livesCount()
				end
		end



		local createJoystick = function()

			leftarrow = display.newImage("L_arrow.png")
			leftarrow.x=350
			leftarrow.y=280
			leftarrow:toFront( )

			rightarrow = display.newImage("R_arrow.png")
			rightarrow.x=450
			rightarrow.y=280
			rightarrow:toFront( )

			uparrow = display.newImage("U_arrow.png")
			uparrow.x=400
			uparrow.y=240
			uparrow:toFront( )

			dpadScreen = display.newImage( "dpadScreen.png" ,0,0,true )
			dpadScreen.x=display.contentWidth/8
			dpadScreen.y=display.contentHeight/2
			gameGroup:insert(leftarrow)
			gameGroup:insert(rightarrow)
			gameGroup:insert(uparrow)
			gameGroup:insert(dpadScreen)
		end




		local destroyEverything = function()
				-- Destroy dpad
				dpadMgr.destroy(dpad)
				dpad = nil
				dpadMgr.destroyMgr()
				dpadMgr = nil
		end

		local createCamera = function()
				camera:add(charObject, 1, false)
				camera:add(ground, 2, false)
				camera:add(bullets,3,false)
				camera:add(charObjectHand,4,false)
				camera:add(groundLeft,5,false)
				camera:add(groundRight,5,false)
				camera.x = charObject.x/2-30
				camera.y = charObject.y/2-250
				camera:setFocus(charObject)
				camera:setBounds(120,800,1,0)
				camera.damping=0
				camera:track()
				gameGroup:insert(camera)
		end	 

		local enemySpawn = function()
			 sheetData = { width=64, height=55, numFrames=14, sheetContentWidth=448, sheetContentHeight=110}
			 mySheet = graphics.newImageSheet( "tester.png", sheetData )
			 sequenceData = {
  				{ name = "RRun",frames={1,2,3,4,5,6,7}, time=1000, loopCount=0},
  					{ name = "LRun",frames={14,13,12,11,10,9,8}, time=1000, loopCount=0}  --add loopCount=4
 					-- { name = "RRun", frames={ 7,8,8,10,11,12,19,20,21,22,23,24,31,32,33,34,35,36,43,44,45,46,47,48 }, time=800,loopCount=5 }
				}



			local enemy = display.newSprite( mySheet, sequenceData )
 			
			
			local xPos = math.random(-150,1000)
			
			enemy.x=xPos
			enemy.y=-100
			--enemy:setSequence( "run1R")
			--enemy:play()
			enemy.myName="enemy"
			enemyFilter = { categoryBits = 4, maskBits = 123, groupIndex = 0 } 
			enemyBody = { friction=0.4, bounce=0, bodyType="dynamic",filter=enemyFilter}
			physics.addBody( enemy,enemyBody)
			enemy.isFixedRotation=true
			enemy.isMovingRight = true
			enemy.speed=0.001
			enemy.xx=enemy.x
			enemy:play()
			gameGroup:insert( enemy )
			local checkMoveEnemy = function()
					--print(enemy.x)
					if(enemy.x==nil) then
						enemy.x=enemy.xx

					end
				if(charObject.x<=enemy.x) then
					
					enemy.isMovingRight=false
					enemy.speed = -1
				else
					enemy.isMovingRight=true
					enemy.speed = 1
				end
				enemy.xx=enemy.x
			end
			local moveEnemy = function( )
				checkMoveEnemy()
				enemy.x=enemy.x + enemy.speed
			end
			--if enemy.x~=nil
				Runtime:addEventListener( "enterFrame", moveEnemy )

			


			



			
			camera:add(enemy,5,false)
		end
			





		local enemyTimer = function()
				startEnemy = timer.performWithDelay( 5000, enemySpawn, 0 )
		end

		local gameStart = function()
			local highScoreFilename = "highScore.data"
			local loadedHighScore = loadValue( highScoreFilename )
			highScore = tonumber(loadedHighScore)
			
			physics.start()
			drawBackground()
			createChar()
			enemyTimer()
			createCamera()
			hud()
			gameActivate()
			createJoystick()
			leftarrow:addEventListener("touch", moveLeft)
			rightarrow:addEventListener("touch", moveRight)
			Runtime:addEventListener("collision",allowJump)
			uparrow:addEventListener( "touch", moveUp)
			Runtime:addEventListener( "touch", stop)
			Runtime:addEventListener("enterFrame",movePlayer)
			dpadScreen:addEventListener("touch", touchManager)
			dpadScreen:addEventListener( "touch", shoot )
			Runtime:addEventListener('enterFrame',updateBullets)
			Runtime:addEventListener("collision",collisionBulletWithWorld)
			Runtime:addEventListener("collision",collisionBulletWithEnemy)
			Runtime:addEventListener("collision",collisionPlayerWithEnemy)
			dpadScreen:addEventListener( "touch", shooting )
		end





		gameStart()
		print( "maingame: enterScene event" )

end


-- Called when scene is about to move offscreen:
function scene:exitScene( event )
	--camera=nil
	physics.stop()
	Runtime:removeEventListener("collision",allowJump)
	Runtime:removeEventListener("collision",collisionBulletWithWorld)
	Runtime:removeEventListener("collision",collisionBulletWithEnemy)
	Runtime:removeEventListener("collision",collisionPlayerWithEnemy)
	print( "maingame: exitScene event" )
	camera:destroy()
end
----

-- Called prior to the removal of scene's "view" (display group)
function scene:destroyScene( event )
	print( "((destroying maingame's view))" )
	physics.stop()
	timer.cancel( startEnemy )
end

---------------------------------------------------------------------------------
-- END OF YOUR IMPLEMENTATION
---------------------------------------------------------------------------------

-- "createScene" event is dispatched if scene's view does not exist
scene:addEventListener( "createScene", scene )

-- "enterScene" event is dispatched whenever scene transition has finished
scene:addEventListener( "enterScene", scene )

-- "exitScene" event is dispatched before next scene's transition begins
scene:addEventListener( "exitScene", scene )

-- "destroyScene" event is dispatched before view is unloaded, which can be
-- automatically unloaded in low memory situations, or explicitly via a call to
-- storyboard.purgeScene() or storyboard.removeScene().
scene:addEventListener( "destroyScene", scene )

---------------------------------------------------------------------------------

return scene
		
