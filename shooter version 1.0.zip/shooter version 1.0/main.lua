display.setStatusBar( display.HiddenStatusBar )
local storyboard = require ( "storyboard" )
storyboard.gotoScene( "loadmainmenu" )